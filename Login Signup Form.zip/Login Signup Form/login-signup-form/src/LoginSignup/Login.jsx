import React, { useState } from 'react'
import Navbar from './Navbar'
import img2 from '../Images/img2.png'
import { useNavigate } from 'react-router'

const Login = () => {
    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")
    const [msg,setMsg] = useState("")
    const [showPassword, setShowPassword] = useState(false);

    const navigate = useNavigate()

const handleInput = (event)=>{
    const value = event.target.value;
    const name = event.target.name;
    if("email" == name){
       setEmail(value)
    }
    if("password" == name){
        setPassword(value)
    }
}

const handleSubmit = (event)=>{
      event.preventDefault();
      if(email == "" || password == ""){
        alert("Please Enter Details!")
      }
      else{

        let getDetials = JSON.parse(localStorage.getItem("user"));
        console.log(getDetials)
        getDetials.map((curValue)=>{
          console.log(curValue.email)
          let storeEmail = curValue.email;
          let storePassword = curValue.password;
          
          if(storeEmail == email && storePassword == password){
           alert('Login Successfully!')
           navigate("/home")
          }
          else{
              return setMsg("Invalid Email or Password !")
          }
        })

      }
     
}

  return (
    <div>
       <Navbar/>
      <div>
      <p className='errMsg'>{msg}</p>
      <form className='login-form' onSubmit={handleSubmit}>  
      <div className='heading'>
        <div> <img src={img2} alt='...' className='imge'/> </div>
         <p> Log In </p> </div>
         <div className='account'>
          
        
         <div className='position-relative'>
  <i className="bi bi-envelope-at input-icon"></i>
  <input 
    type='email' 
    name='email'     
    placeholder='Enter Your Email'  
    value={email}
    onChange={handleInput}
    className="custom-placeholder"
    required
    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
    title="Please enter a valid email address"
  />
</div>

<div className='position-relative'>
  <i className="bi bi-database-lock input-icon"></i>
  <input 
    type={showPassword ? 'text' : 'password'}
    name='password'  
    placeholder='Enter Your Password'  
    value={password}
    onChange={handleInput}
    className="custom-placeholder"
    required
    minLength="6"
    title="Password must be at least 6 characters"
  />
  <i 
    className={`bi ${showPassword ? 'bi-eye-slash' : 'bi-eye'} toggle-password`} 
    onClick={() => setShowPassword(!showPassword)} 
    style={{ position: 'absolute', right: '30px', top: '68%', transform: 'translateY(-50%)', cursor: 'pointer', color:'rgb(66, 64, 64)' }}
  ></i>
</div>
            <p> If you have to create account  ? <a href='/'> SignUp </a></p>
         </div>
         <button> LogIn </button>
        </form>
      </div>
    </div>
  )
}

export default Login
