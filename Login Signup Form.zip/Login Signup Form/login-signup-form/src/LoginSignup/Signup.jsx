import React, { useState } from 'react';
import Navbar from './Navbar';
import img5 from '../Images/img5.avif';
import img1 from '../Images/img1.jpg'
import { useNavigate } from 'react-router';

const Signup = () => {
  const userDetail = {
    name: "",
    email: "",
    password: ""
  };

  const [data, setData] = useState(userDetail);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleInput = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setData({ ...data, [name]: value });
  };

  const validateName = (name) => {
    return /^[A-Za-z\s]+$/.test(name);
  };
const validateEmail = (email) => {
    return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
  };
      
  const handleSubmit = (event) => {
    event.preventDefault();
  
    if (data.name === "" || data.email === "" || data.password === "") {
      alert("Please enter all details!");
    } else if (!validateName(data.name)) {
      alert("Name should contain only characters!");
    } else if (!validateEmail(data.email)) {
      alert("Please enter a valid email address!");
    } else if (data.password.length < 6) {
      alert("Password must be at least 6 characters long!");
    } else {
      const getData = JSON.parse(localStorage.getItem("user") || "[]");
      const updatedData = [...getData, data];
      localStorage.setItem("user", JSON.stringify(updatedData));
      alert("Signup Successfully!");
      navigate("/login");
    }
  };

  return (
    <div>
      <Navbar />
      <div className='main-page'>
        <form onSubmit={handleSubmit}>
          <div className='heading'>
          <div> <img src={img1} alt='...' className='img'/> </div>
            <p> Sign Up </p>
          </div>
          <div className='account'>

            <div className='position-relative'>
              <i className="bi bi-person input-icon"></i>
              <input
                type='text'
                name='name'
                value={data.name}
                placeholder="Enter Your Name"
                onChange={handleInput}
                className="custom-placeholder"
              />
            </div>

            <div className='position-relative'>
              <i className="bi bi-envelope-at input-icon"></i>
              <input
                type='email'
                name='email'
                value={data.email}
                placeholder='Enter Your Email'
                onChange={handleInput}
                className="custom-placeholder"
              />
            </div>

            <div className='position-relative'>
              <i className="bi bi-database-lock input-icon"></i>
              <input
                type={showPassword ? 'text' : 'password'}
                name='password'
                value={data.password}
                placeholder='Enter Your Password'
                onChange={handleInput}
                className="custom-placeholder"
              />
              <i
                className={`bi ${showPassword ? "bi-eye-slash" : "bi-eye"} password-toggle-icon`}
                onClick={() => setShowPassword(!showPassword)}
                style={{ position: "absolute", right: "30px", top: "68%", transform: "translateY(-50%)", cursor: "pointer",  color:'rgb(66, 64, 64)'}}
              ></i>
            </div>

            <p> Already have an account ? <a href='/login'>Login</a> </p>
          </div>
          <button type='submit'> SignUp </button>
        </form>
        <div>
          <img src={img5} alt='...' />
        </div>
      </div>
    </div>
  );
};

export default Signup;
