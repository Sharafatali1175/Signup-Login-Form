import React from 'react'
import Navbar from './Navbar'
import welcome from '../Images/welcome.avif';
import { useNavigate } from 'react-router'

const Home = () => {
    const navigate = useNavigate()
    const logOut = ()=>{
        localStorage.removeItem("user")
        navigate('/')
    }
  return (
    <div>
        <Navbar/>
      <div className='home'>
          <h2> <i> Wellcome To Home Page </i> !</h2>
          <button onClick={logOut}> Logout </button>
        </div>
        <div className='welcom'><img src={welcome} alt='...'/> </div>
    </div>
    
  )
}

export default Home
