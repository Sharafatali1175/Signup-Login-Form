import React from 'react';
import logo from '../Images/logo.avif';
const Navbar = () => {
  return (
    <div className='main'>
      <nav>
      <ul>
        <li> 
         <a className='head' href='#'> <img src={logo} alt='...' className='logo'/> </a>
         <a href='#'> Explore! </a>
         <a href='#'> Contact Us  </a>
         <a href='#'> About Us  </a>  
        </li>
      </ul>

      </nav>
    </div>
  )
}

export default Navbar
